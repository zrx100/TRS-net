6 functions for generating artificial datasets
